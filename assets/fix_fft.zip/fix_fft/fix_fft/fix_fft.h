
#ifndef FIXFFT_H
#define FIXFFT_H

#include "Arduino.h"

int fix_fft(char fr[], char fi[], int m, int inverse);


int fix_fftr(char f[], int m, int inverse);

#endif